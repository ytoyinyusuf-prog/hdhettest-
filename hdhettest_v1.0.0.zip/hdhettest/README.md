# hdhettest

Heteroskedasticity tests with exact Monte Carlo p-values for linear regressions with many regressors (Stata 14+).

Coefficient-of-variation and approximate likelihood-ratio tests (Li and Yao 2019; Bai, Pan and Yin 2018), Koenker (1981) tests on the regressors and the fitted values, and a Jarque-Bera pre-test, all with Monte Carlo p-values that have exact size under Gaussian errors for any number of regressors (Dufour et al. 1998, 2004). Option `robust` draws heavy-tailed errors with the estimated kurtosis.

## Installation

```
net install hdhettest, from("folder or URL containing hdhettest.pkg")
```

## Example

```
bcuse wage1, clear
regress lwage i.educ i.exper i.tenure female married nonwhite smsa
hdhettest, seed(20261025)
```

Author: Yusuf Toyin Yusuf, Kwara State University (yusuf.yusuf@kwasu.edu.ng). License: MIT.
